/*
  ==============================================================================

  This is an automatically generated GUI class created by the Projucer!

  Be careful when adding custom code to these files, as only the code within
  the "//[xyz]" and "//[/xyz]" sections will be retained when the file is loaded
  and re-saved.

  Created with Projucer version: 7.0.12

  ------------------------------------------------------------------------------

  The Projucer is part of the JUCE library.
  Copyright (c) 2020 - Raw Material Software Limited.

  ==============================================================================
*/

//[Headers] You can add your own extra header files here...
//[/Headers]

#include "PluginEditor.h"


//[MiscUserDefs] You can add your own user definitions and misc code here...
//[/MiscUserDefs]

//==============================================================================
GainAudioProcessorEditor::GainAudioProcessorEditor (GainAudioProcessor* ownerFilter)
    : AudioProcessorEditor(ownerFilter)
{
    //[Constructor_pre] You can add your own custom stuff here..
    //[/Constructor_pre]

    gainSlider.reset (new juce::Slider ("Gain Slider"));
    addAndMakeVisible (gainSlider.get());
    gainSlider->setRange (-70, 0, 0.1);
    gainSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    gainSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 40, 20);
    gainSlider->addListener (this);

    gainSlider->setBounds (176, 88, 190, 32);

    gainLabel.reset (new juce::Label ("Gain Label",
                                      TRANS ("Nivel [dB]")));
    addAndMakeVisible (gainLabel.get());
    gainLabel->setFont (juce::Font (15.00f, juce::Font::plain).withTypefaceStyle ("Regular"));
    gainLabel->setJustificationType (juce::Justification::centredLeft);
    gainLabel->setEditable (false, false, false);
    gainLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    gainLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    gainLabel->setBounds (24, 96, 134, 32);

    frecvSlider.reset (new juce::Slider ("Slider Frecventa"));
    addAndMakeVisible (frecvSlider.get());
    frecvSlider->setRange (20, 20000, 1);
    frecvSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    frecvSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 50, 20);
    frecvSlider->addListener (this);
    frecvSlider->setSkewFactor (0.3);

    frecvSlider->setBounds (168, 128, 222, 24);

    frecvLabel.reset (new juce::Label ("Label Frecventa",
                                       TRANS ("Frecventa [Hz]")));
    addAndMakeVisible (frecvLabel.get());
    frecvLabel->setFont (juce::Font (15.00f, juce::Font::plain).withTypefaceStyle ("Regular"));
    frecvLabel->setJustificationType (juce::Justification::centredLeft);
    frecvLabel->setEditable (false, false, false);
    frecvLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    frecvLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    frecvLabel->setBounds (24, 128, 150, 24);

    delayLabel.reset (new juce::Label ("Delay Label",
                                       TRANS ("Delay [ms]")));
    addAndMakeVisible (delayLabel.get());
    delayLabel->setFont (juce::Font (15.00f, juce::Font::plain).withTypefaceStyle ("Regular"));
    delayLabel->setJustificationType (juce::Justification::centredLeft);
    delayLabel->setEditable (false, false, false);
    delayLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    delayLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    delayLabel->setBounds (24, 48, 150, 24);

    delaySlider.reset (new juce::Slider ("Delay Slider"));
    addAndMakeVisible (delaySlider.get());
    delaySlider->setRange (0, 2000, 100);
    delaySlider->setSliderStyle (juce::Slider::LinearHorizontal);
    delaySlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    delaySlider->addListener (this);
    delaySlider->setSkewFactor (0.5);

    delaySlider->setBounds (104, 48, 286, 24);


    //[UserPreSize]
    //[/UserPreSize]

    setSize (400, 200);


    //[Constructor] You can add your own custom stuff here..
    getProcessor()->RequestUIUpdate();
    startTimer(200);
    //[/Constructor]
}

GainAudioProcessorEditor::~GainAudioProcessorEditor()
{
    //[Destructor_pre]. You can add your own custom destruction code here..
    //[/Destructor_pre]

    gainSlider = nullptr;
    gainLabel = nullptr;
    frecvSlider = nullptr;
    frecvLabel = nullptr;
    delayLabel = nullptr;
    delaySlider = nullptr;


    //[Destructor]. You can add your own custom destruction code here..
    //[/Destructor]
}

//==============================================================================
void GainAudioProcessorEditor::paint (juce::Graphics& g)
{
    //[UserPrePaint] Add your own custom painting code here..
    //[/UserPrePaint]

    g.fillAll (juce::Colour (0xff095277));

    //[UserPaint] Add your own custom painting code here..
    //[/UserPaint]
}

void GainAudioProcessorEditor::resized()
{
    //[UserPreResize] Add your own custom resize code here..
    //[/UserPreResize]

    //[UserResized] Add your own custom resize handling here..
    //[/UserResized]
}

void GainAudioProcessorEditor::sliderValueChanged (juce::Slider* sliderThatWasMoved)
{
    //[UsersliderValueChanged_Pre]
    GainAudioProcessor* ourProcessor = getProcessor();
    //[/UsersliderValueChanged_Pre]

    if (sliderThatWasMoved == gainSlider.get())
    {
        //[UserSliderCode_gainSlider] -- add your slider handling code here..
        float normValue = powf(10.f, (float)gainSlider->getValue() / 20.f);
        ourProcessor->setParameter(GainAudioProcessor::gain, normValue);
        //[/UserSliderCode_gainSlider]
    }
    else if (sliderThatWasMoved == frecvSlider.get())
    {
        //[UserSliderCode_frecvSlider] -- add your slider handling code here..
        float val = (float)frecvSlider->getValue();
        float valNorm = (val - 20.f) / (20000.f - 20.f);
        ourProcessor->setParameter(GainAudioProcessor::frecv, valNorm);
        //[/UserSliderCode_frecvSlider]
    }
    else if (sliderThatWasMoved == delaySlider.get())
    {
        //[UserSliderCode_delaySlider] -- add your slider handling code here..
        float valoare = (float)delaySlider->getValue();
        float valN = valoare / 2000.f;
        ourProcessor->setParameter(GainAudioProcessor::delay, valN);

        //[/UserSliderCode_delaySlider]
    }

    //[UsersliderValueChanged_Post]
    //[/UsersliderValueChanged_Post]
}



//[MiscUserCode] You can add your own definitions of your custom methods or any other code here...

    void GainAudioProcessorEditor::timerCallback()
    {
        GainAudioProcessor* ourProcessor = getProcessor();
        //se schimba datele dorite intre elementele interfetei grafice si modulul “ourProcessor”
        if (ourProcessor->NeedsUIUpdate())
        {
            float dbValue = 20.f * log10(ourProcessor->getParameter(GainAudioProcessor::gain));
            gainSlider->setValue(dbValue, juce::dontSendNotification);

            float valNorm = ourProcessor->getParameter(GainAudioProcessor::frecv);
            float val = valNorm * (20000.f - 20.f) + 20.f;
            frecvSlider->setValue(val, juce::dontSendNotification);

            float valN= ourProcessor->getParameter(GainAudioProcessor::delay);
            float valoare = valN * 2000.f;
            delaySlider->setValue(valoare, juce::dontSendNotification);


            ourProcessor->ClearUIUpdateFlag();
        }
    }
//[/MiscUserCode]


//==============================================================================
#if 0
/*  -- Projucer information section --

    This is where the Projucer stores the metadata that describe this GUI layout, so
    make changes in here at your peril!

BEGIN_JUCER_METADATA

<JUCER_COMPONENT documentType="Component" className="GainAudioProcessorEditor"
                 componentName="" parentClasses="public AudioProcessorEditor, public Timer"
                 constructorParams="GainAudioProcessor* ownerFilter" variableInitialisers="AudioProcessorEditor(ownerFilter)"
                 snapPixels="8" snapActive="1" snapShown="1" overlayOpacity="0.330"
                 fixedSize="1" initialWidth="400" initialHeight="200">
  <BACKGROUND backgroundColour="ff095277"/>
  <SLIDER name="Gain Slider" id="6fc5d68b2835740" memberName="gainSlider"
          virtualName="" explicitFocusOrder="0" pos="176 88 190 32" min="-70.0"
          max="0.0" int="0.1" style="LinearHorizontal" textBoxPos="TextBoxLeft"
          textBoxEditable="1" textBoxWidth="40" textBoxHeight="20" skewFactor="1.0"
          needsCallback="1"/>
  <LABEL name="Gain Label" id="2264c4a6faf91a4b" memberName="gainLabel"
         virtualName="" explicitFocusOrder="0" pos="24 96 134 32" edTextCol="ff000000"
         edBkgCol="0" labelText="Nivel [dB]" editableSingleClick="0" editableDoubleClick="0"
         focusDiscardsChanges="0" fontname="Default font" fontsize="15.0"
         kerning="0.0" bold="0" italic="0" justification="33"/>
  <SLIDER name="Slider Frecventa" id="1343b8587252b95c" memberName="frecvSlider"
          virtualName="" explicitFocusOrder="0" pos="168 128 222 24" min="20.0"
          max="20000.0" int="1.0" style="LinearHorizontal" textBoxPos="TextBoxLeft"
          textBoxEditable="1" textBoxWidth="50" textBoxHeight="20" skewFactor="0.3"
          needsCallback="1"/>
  <LABEL name="Label Frecventa" id="7b24a413d021a5ff" memberName="frecvLabel"
         virtualName="" explicitFocusOrder="0" pos="24 128 150 24" edTextCol="ff000000"
         edBkgCol="0" labelText="Frecventa [Hz]" editableSingleClick="0"
         editableDoubleClick="0" focusDiscardsChanges="0" fontname="Default font"
         fontsize="15.0" kerning="0.0" bold="0" italic="0" justification="33"/>
  <LABEL name="Delay Label" id="78875d318b93de4a" memberName="delayLabel"
         virtualName="" explicitFocusOrder="0" pos="24 48 150 24" edTextCol="ff000000"
         edBkgCol="0" labelText="Delay [ms]" editableSingleClick="0" editableDoubleClick="0"
         focusDiscardsChanges="0" fontname="Default font" fontsize="15.0"
         kerning="0.0" bold="0" italic="0" justification="33"/>
  <SLIDER name="Delay Slider" id="46ae92ec631333e3" memberName="delaySlider"
          virtualName="" explicitFocusOrder="0" pos="104 48 286 24" min="0.0"
          max="2000.0" int="100.0" style="LinearHorizontal" textBoxPos="TextBoxLeft"
          textBoxEditable="1" textBoxWidth="80" textBoxHeight="20" skewFactor="0.5"
          needsCallback="1"/>
</JUCER_COMPONENT>

END_JUCER_METADATA
*/
#endif


//[EndFile] You can add extra defines here...
//[/EndFile]

