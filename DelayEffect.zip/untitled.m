clc
close all
% 1. Citirea fișierului audio
[x, fs] = audioread('elephant.wav');

% 2. Parametrii filtrului FIR comb
g = 0.7; % Factor de atenuare
M = round(1 * fs); % Întârziere de 1 secunda
 
Delayline = zeros(M, 1); % Linie de întârziere

% 3. Aplicarea filtrului FIR comb
y = zeros(size(x));
for n = 1:length(x)
    y(n) = x(n) + g * Delayline(M);
    Delayline = [x(n); Delayline(1:M-1)];
end

% 4. Afișarea semnalelor originale și filtrate
figure;
t = (0:length(x)-1) / fs;
subplot(2,1,1);
plot(t, x);
title('Semnal Original');
xlabel('Timp (s)'); ylabel('Amplitudine');

t = (0:length(y)-1) / fs;
subplot(2,1,2);
plot(t, y);
title('Semnal Filtrat (FIR Comb)');
xlabel('Timp (s)'); ylabel('Amplitudine');

% 5. Ascultarea semnalelor
sound(x, fs); % Original
pause(length(x)/fs + 1);
sound(y, fs); % Filtrat

% 6. Analiză în frecvență
NFFT = 2^nextpow2(length(x));
f = fs * (0:(NFFT/2))/NFFT;

X = abs(fft(x, NFFT));
Y = abs(fft(y, NFFT));

figure;
plot(f, X(1:NFFT/2+1), 'b', 'LineWidth', 1.5); hold on;
plot(f, Y(1:NFFT/2+1), 'r', 'LineWidth', 1.5);
legend('Original', 'Filtrat');
xlabel('Frecvență (Hz)'); ylabel('Amplitudine');
title('Spectru Semnal Original vs. Filtrat');

% 7. Salvarea semnalului filtrat
audiowrite('output_audio_fir_comb.wav', y, fs);
